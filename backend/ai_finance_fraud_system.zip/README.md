# 🛡️ Sentinel — Autonomous AI Personal Finance & Intelligent Fraud Shield

An enterprise-grade, full-stack Python application combining **multi-currency personal wealth analytics** with an **explainable real-time AI fraud detection engine**.

---

## 📁 Project Structure

```
ai_finance_fraud_system/
│
├── run.bat                     # 1-Click Windows Launcher (Double-click to start!)
├── README.md                   # Setup guide & documentation
│
├── backend/                    # Python FastAPI Backend
│   ├── main.py                 # FastAPI application routes & API server
│   ├── database.py             # SQLAlchemy 2.0 SQLite database configuration
│   ├── models.py               # Relational database models
│   ├── schemas.py              # Pydantic v2 schemas
│   ├── fraud_engine.py         # AI & statistical anomaly detection engine
│   ├── finance_engine.py       # Cashflow, budget & forecasting engine
│   ├── ai_advisor.py           # AI financial advisor & what-if simulator
│   ├── seed_data.py            # Database population script with demo records
│   ├── test_api.py             # Automated unit test suite (10 test cases)
│   └── requirements.txt        # Backend dependencies
│
└── frontend/                   # Modern Luxury Single-Page Application (SPA)
    ├── index.html              # Semantic HTML5 layout
    ├── styles.css              # Bespoke dark/light & page-specific theme CSS
    └── app.js                  # Reactive frontend controller & Chart.js engine
```

---

## 🚀 How to Run (Step-by-Step)

### Option 1: 1-Click Launcher (Windows)
Just double-click **`run.bat`** in the project folder. It will automatically install dependencies, seed the database, and start the local server.

---

### Option 2: Run via Terminal / Command Prompt

#### Step 1: Open Terminal in the `backend` folder
```powershell
cd backend
```

#### Step 2: (Optional but Recommended) Create a Virtual Environment
```powershell
python -m venv venv
venv\Scripts\activate
```

#### Step 3: Install Dependencies
```powershell
python -m pip install -r requirements.txt
```

#### Step 4: Initialize & Seed the Database
```powershell
python seed_data.py
```

#### Step 5: Start the Server
```powershell
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

#### Step 6: Open the Application
Open your web browser and navigate to:
* **Web Dashboard:** [http://127.0.0.1:8000](http://127.0.0.1:8000)
* **Interactive API Documentation:** [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

---

## 🧪 Run Automated Tests

To run the automated test suite verifying all 10 API endpoints and fraud detection rules:
```powershell
cd backend
python test_api.py
```

---

## 🌟 Key Features
* 🇮🇳 **Multi-Currency Support**: Instant currency conversion for **INR (₹)**, USD ($), EUR (€), GBP (£), JPY (¥), AED, CAD, AUD.
* 🛡️ **AI Multi-Vector Fraud Engine**: Evaluates impossible geo-velocity, Z-score amount outliers, card-testing micro-bursts, off-hour transactions, and merchant blocklists.
* 🔍 **Explainable AI Risk Reports**: Click *"AI Report"* on any transaction to inspect mathematical anomaly factors.
* 🔮 **Predictive Expense Forecasting**: Burn-rate trajectory charting end-of-month spending vs budget caps.
* 💡 **What-If Wealth Optimizer**: Simulates 5-year and 10-year compound wealth growth at 7% market return.
* 👁️ **Privacy Mode**: 1-click toggle to blur all sensitive account balances.
* 🚨 **Emergency Lockdown**: 1-click panic freeze to secure all cards and accounts.
* 🌓 **Creative Dark & Light Themes**: Dynamic theme switcher with automatic Chart.js color adaptation.
